1. "VC_redist.x64.exe"를 먼저 설치하세요.
2. "megavnc_server.exe"를 실행하고 지침을 따르세요. 관리자 권한이 필요합니다.